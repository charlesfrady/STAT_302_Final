library(shiny)
library(readr)
library(dplyr)
library(tidyr)
library(ggplot2)
library(bslib)

pitch_arsenals_speed <- read_csv("data/pitch_arsenals_speed.csv")
pitch_arsenals_spin  <- read_csv("data/pitch_arsenals_spin_rates.csv")
pitch_arsenals_usage <- read_csv("data/pitch_arsenals_usage.csv") 

get_numeric_cols <- function(df, exclude_cols = c("pitcher", "first_name", "last_name")) {
  setdiff(names(df)[sapply(df, is.numeric)], exclude_cols)
}

speed_cols <- get_numeric_cols(pitch_arsenals_speed)
spin_cols  <- get_numeric_cols(pitch_arsenals_spin)
usage_cols <- grep("^n_", names(pitch_arsenals_usage), value = TRUE)

speed_long <- pitch_arsenals_speed %>%
  pivot_longer(all_of(speed_cols), names_to = "pitch_type", values_to = "velocity") %>%
  mutate(pitch_type = gsub("^n_|_avg_speed|_velocity$", "", pitch_type))

spin_long <- pitch_arsenals_spin %>%
  pivot_longer(all_of(spin_cols), names_to = "pitch_type", values_to = "spin_rate") %>%
  mutate(pitch_type = gsub("^n_|_avg_spin|_rpm$", "", pitch_type))

usage_long <- pitch_arsenals_usage %>%
  pivot_longer(all_of(usage_cols), names_to = "pitch_type", values_to = "usage") %>%
  mutate(pitch_type = gsub("^n_", "", pitch_type))

pitch_data <- speed_long %>%
  left_join(spin_long, by = c("pitcher", "pitch_type")) %>%
  left_join(usage_long, by = c("pitcher", "pitch_type"))

pitch_names <- c(
  ff = "Four-Seam Fastball",
  si = "Sinker",
  fc = "Cutter",
  sl = "Slider",
  ch = "Changeup",
  cu = "Curveball",
  fs = "Splitter",
  kn = "Knuckleball",
  st = "Sweeper",
  sv = "Slurve"
)

pitch_data <- pitch_data %>%
  mutate(pitch_name = pitch_names[pitch_type])

ui <- fluidPage(
  theme = bs_theme(
    version = 5,
    bg = "black",        
    fg = "white",        
    primary = "blue",
    secondary = "orange",
    base_font = font_google("Roboto"),
    heading_font = font_google("Montserrat")
  ),
  titlePanel("⚾ Pitch Arsenal Dashboard"),
  tabsetPanel(
    tabPanel("Introduction",
             fluidPage(
               h2("Introduction"),
               p("The following shiny app is meant to showcase MLB pitch arsenal data for the 2024 season.
                 the app will allow you to explore trends across velocity, spin rates, and usage. 
                 Aggregated by pitch type, you will have the opportunity to see general trends across
                 these three pitch arsenal KPIs in addition to how they affect one another.")
             )
    ),
    tabPanel("General Trends",
             sidebarLayout(
               sidebarPanel(
                 selectInput(
                   "trendType", "Choose Metric:",
                   choices = c(
                     "Usage" = "usage",
                     "Spin Rate" = "spin",
                     "Velocity" = "velocity"
                   )
                 ),
                 style = "background-color:#1a1a1a; color:white;"  # dark sidebar
               ),
               mainPanel(
                 plotOutput("trendPlot", height = "500px")
               )
             )
    ),
    tabPanel("Comparison",
             sidebarLayout(
               sidebarPanel(
                 selectInput(
                   "compType", "Choose Comparison:",
                   choices = c(
                     "Velocity vs Spin Rate" = "velo_spin",
                     "Velocity vs Usage" = "velo_usage",
                     "Spin Rate vs Usage" = "spin_usage"
                   )
                 ),
                 selectInput(
                   "compPitchType", "Select Pitch Type:",
                   choices = sort(unique(pitch_data$pitch_name))
                 ),
                 style = "background-color:#1a1a1a; color:white;"  # dark sidebar
               ),
               mainPanel(
                 plotOutput("compPlot", height = "500px")
               )
             )
    ),
    tabPanel("Conclusion",
             fluidPage(
               h2("Conclusion"),
               p("As you likely had an opportunity to explore under the data tabs, 
                 the pitch arsenal vary a lot. Here are some takeaways."),
               p("- These is a generally higher usage of four-seam fastballs."),
               p("- Offspeed offerings have generally lower spin rates."),
               p("- Across all pitch types, you will see higher spin rates for pitches with higher velos."),
               p("- Some pitches will have less usage when thrown harder (Changeups, Knuckleballs, Sinkers, & Sweepers). 
                 All other pitch types will see an increase in usage as  the average veloicty increases."),
               p("- Some pitches will have more usage with lower spin rates (Knuckleballs, Sinkers, & Splitters). 
                 All other pitch types will see an increase in usage as the average spin rate increases."),
               p("These takeaways/data have nothing to do with anything related to actual in-game performance trends.")
             )
    ),
    tabPanel("Data Source",
             fluidPage(
               h2("Citations"),
               p("For my project I used Baseball Savant pitch arsenal data for the 2024 season. 
                 This includes three CSVs that explain the pitch velocities, usage, and spin rates."),
               h3("Pitch Arsenal Velocity Data"),
               tags$a(href="https://drive.google.com/file/d/16ZEXIdLxcUqpToZuExL1vDMs1eYuL7q_/view?usp=sharing", 
                      "Pitch Arsenal Velocity CSV", target="_blank"),
               p("Includes every MLB pitcher from 2024 with a breakdown of their average velocity by assigned pitch tags. 
                 Filtered only by MLB’s qualifier parameters."),
               h3("Pitch Arsenal Usage Data"),
               tags$a(href="https://drive.google.com/file/d/1CYdRS1V6xUPtmRlqxdDPj8QUkJMbhCUW/view?usp=sharing", 
                      "Pitch Arsenal Usage CSV", target="_blank"),
               p("Includes every MLB pitcher from 2024 with a breakdown of their usage of pitches as assigned by their pitch tags. 
                 Filtered only by MLB’s qualifier parameters."),
               h3("Pitch Arsenal Spin Rates Data"),
               tags$a(href="https://drive.google.com/file/d/1svV5SJpWWP9kEBeEPKiSbo8re1gZWrer/view?usp=sharing", 
                      "Pitch Arsenal Spin Rates CSV", target="_blank"),
               p("Includes every MLB pitcher from 2024 with a breakdown of spin rates by pitch type as assigned by their pitch tags. 
                 Filtered only by MLB’s qualifier parameters.")
             )
    )
  )
)

server <- function(input, output) {
  output$trendPlot <- renderPlot({
    data <- pitch_data
    plot_theme <- theme(
      panel.background = element_rect(fill = "black"),
      plot.background = element_rect(fill = "black"),
      panel.grid.major = element_line(color = "grey"),
      panel.grid.minor = element_line(color = "black"),
      axis.text = element_text(color = "white"),
      axis.title = element_text(color = "white"),
      plot.title = element_text(color = "white", face = "bold")
    )
    if (input$trendType == "usage") {
      ggplot(data, aes(x = pitch_name, y = usage)) +
        geom_boxplot(fill = "blue", alpha = 0.8) +
        scale_y_continuous(labels = function(x) paste0(x, "%")) +
        labs(title = "General Usage Across MLB", y = "Usage %", x = "Pitch Type") +
        theme_minimal(base_size = 14) + plot_theme +
        theme(axis.text.x = element_text(angle = 45, hjust = 1))
    } else if (input$trendType == "spin") {
      ggplot(data, aes(x = pitch_name, y = spin_rate)) +
        geom_boxplot(fill = "green", alpha = 0.8) +
        labs(title = "Spin Rate Trends by Pitch Type", y = "Spin Rate (RPM)", x = "Pitch Type") +
        theme_minimal(base_size = 14) + plot_theme +
        theme(axis.text.x = element_text(angle = 45, hjust = 1))
    } else if (input$trendType == "velocity") {
      ggplot(data, aes(x = pitch_name, y = velocity)) +
        geom_boxplot(fill = "red", alpha = 0.8) +
        labs(title = "Velocity Trends by Pitch Type", y = "Velocity (MPH)", x = "Pitch Type") +
        theme_minimal(base_size = 14) + plot_theme +
        theme(axis.text.x = element_text(angle = 45, hjust = 1))
    }
  })
  
  output$compPlot <- renderPlot({
    data <- filter(pitch_data, pitch_name == input$compPitchType)
    plot_theme <- theme(
      panel.background = element_rect(fill = "black"),
      plot.background = element_rect(fill = "black"),
      panel.grid.major = element_line(color = "grey"),
      panel.grid.minor = element_line(color = "darkgrey"),
      axis.text = element_text(color = "white"),
      axis.title = element_text(color = "white"),
      plot.title = element_text(color = "white", face = "bold")
    )
    if (input$compType == "velo_spin") {
      ggplot(data, aes(x = velocity, y = spin_rate)) +
        geom_point(alpha = 0.7, color = "blue") +
        geom_smooth(method = "lm", se = FALSE, color = "orange") +
        labs(title = paste("Velocity vs Spin Rate -", input$compPitchType),
             x = "Velocity (MPH)", y = "Spin Rate (RPM)") +
        theme_minimal(base_size = 14) + plot_theme
    } else if (input$compType == "velo_usage") {
      ggplot(data, aes(x = velocity, y = usage)) +
        geom_point(alpha = 0.7, color = "orange") +
        geom_smooth(method = "lm", se = FALSE, color = "blue") +
        scale_y_continuous(labels = function(x) paste0(x, "%")) +
        labs(title = paste("Velocity vs Usage -", input$compPitchType),
             x = "Velocity (MPH)", y = "Usage %") +
        theme_minimal(base_size = 14) + plot_theme
    } else if (input$compType == "spin_usage") {
      ggplot(data, aes(x = spin_rate, y = usage)) +
        geom_point(alpha = 0.7, color = "purple") +
        geom_smooth(method = "lm", se = FALSE, color = "orange") +
        scale_y_continuous(labels = function(x) paste0(x, "%")) +
        labs(title = paste("Spin Rate vs Usage -", input$compPitchType),
             x = "Spin Rate (RPM)", y = "Usage %") +
        theme_minimal(base_size = 14) + plot_theme
    }
  })
}

shinyApp(ui = ui, server = server)